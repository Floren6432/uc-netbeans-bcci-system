/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bccisystem;

import java.text.DecimalFormat;
import java.util.Scanner;

public class BcciSystem {
	static double monthlySalary(double salary) {
		Scanner monthlyMoney = new Scanner(System.in);
		System.out.print("Please enter your Montly Salary: ");
		salary = monthlyMoney.nextDouble();
		//monthlyMoney.close();
		return salary; //Monthly Salary
		
	}
	static double incomeTax(double salary) {
		double tax_schedule = 0;
		double annualSalary = salary * 12;
		
		if(annualSalary < 250000){
			tax_schedule = 0.00; //1
		}
		else if(annualSalary >= 250000 && annualSalary < 400000){
			tax_schedule = (0.20 * (annualSalary - 250000)) / 12; //2
		}
		else if(annualSalary >= 400000 && annualSalary < 800000){
			tax_schedule = (30000 + (0.25 * (annualSalary - 400000))) / 12; //3
		}
		else if(annualSalary >= 800000 && annualSalary < 2000000){
			tax_schedule = (130000 + (0.30 * (annualSalary - 800000))) / 12; //4
		}
		else if(annualSalary >= 2000000 && annualSalary < 8000000){
			tax_schedule = (490000 + (0.32 * (annualSalary - 2000000))) / 12; //5
		}
		else if(annualSalary > 8000000){
			tax_schedule = (2410000 + (0.35 * (annualSalary - 8000000))) / 12;
		}
		
		return tax_schedule; //Income Tax
	}
	static int SSS(double salary) {
		int EE = 0;
		if(salary < 2250) {
			EE = 80; //1
		}
		else if(salary >= 2250 && salary < 2749.99) {
			EE = 100; //2
		}
		else if(salary >= 2750 && salary < 3249.99) {
			EE = 120; //3
		}
		else if(salary >= 3250 && salary < 3749.99) {
			EE = 140; //4
		}
		else if(salary >= 3750 && salary < 4249.99) {
			EE = 160; //5
		}
		else if(salary >= 4250 && salary < 4749.99) {
			EE = 180; //6
		}
		else if(salary >= 4750 && salary < 5249.99) {
			EE = 200; //7
		}
		else if(salary >= 5250 && salary < 5749.99) {
			EE = 220; //8
		}
		else if(salary >= 5750 && salary < 6249.99) {
			EE = 240; //9
		}
		else if(salary >= 6250 && salary < 6749.99) {
			EE = 260; //10
		}
		else if(salary >= 6750 && salary < 7249.99) {
			EE = 280; //11
		}
		else if(salary >= 7250 && salary < 7749.99) {
			EE = 300; //12
		}
		else if(salary >= 7750 && salary < 8249.99) {
			EE = 320; //13
		}
		else if(salary >= 8250 && salary < 8749.99) {
			EE = 340; //14
		}
		else if(salary >= 8750 && salary < 9249.99) {
			EE = 360; //15
		}
		else if(salary >= 9250 && salary < 9749.99) {
			EE = 380; //16
		}
		else if(salary >= 9750 && salary < 10249.99) {
			EE = 400; //17
		}
		else if(salary >= 10250 && salary < 10749.99) {
			EE = 420; //18
		}
		else if(salary >= 10750 && salary < 11249.99) {
			EE = 440; //19
		}
		else if(salary >= 11250 && salary < 11749.99) {
			EE = 460; //20
		}
		else if(salary >= 11750 && salary < 12249.99) {
			EE = 480; //21
		}
		else if(salary >= 12250 && salary < 12749.99) {
			EE = 500; //22
		}
		else if(salary >= 12750 && salary < 13249.99) {
			EE = 520; //23
		}
		else if(salary >= 13250 && salary < 13749.99) {
			EE = 540; //24
		}
		else if(salary >= 13750 && salary < 14249.99) {
			EE = 560; //25
		}
		else if(salary >= 14250 && salary < 14749.99) {
			EE = 580; //26
		}
		else if(salary >= 14750 && salary < 15249.99) {
			EE = 600; //27
		}
		else if(salary >= 15250 && salary < 15749.99) {
			EE = 620; //28
		}
		else if(salary >= 15750 && salary < 16249.99) {
			EE = 640; //29
		}
		else if(salary >= 16250 && salary < 16749.99) {
			EE = 660; //30
		}
		else if(salary >= 16750 && salary < 17249.99) {
			EE = 680; //31
		}
		else if(salary >= 17250 && salary < 17749.99) {
			EE = 700; //32
		}
		else if(salary >= 17750 && salary < 18249.99) {
			EE = 720; //33
		}
		else if(salary >= 18250 && salary < 18749.99) {
			EE = 740; //34
		}
		else if(salary >= 18750 && salary < 19249.99) {
			EE = 760; //35
		}
		else if(salary >= 19250 && salary < 19749.99) {
			EE = 780; //36
		}
		else if(salary > 19750) {
			EE = 800; //37
		}
		
		return EE; //SSS
	}
	static double pagIbig(double salary) {
		double employeeShare = 0;
		double percentage;
		
		if(salary <= 1500) {
			percentage = 0.01;
		}
		else {
			percentage = 0.02;
		}
		employeeShare = percentage * salary;
		
		return employeeShare;
	}
	static double philHealth(double salary) {
		double ES = 0;
		if(salary < 8999.99) {
			ES = 100.00; //1
		}
		else if(salary >= 9000.00 && salary < 9999.99) {
			ES = 112.50; //2
		}
		else if(salary >= 10000.00 && salary < 10999.99) {
			ES = 125.00; //3
		}
		else if(salary >= 11000.00 && salary < 11999.99) {
			ES = 137.50; //4
		}
		else if(salary >= 12000.00 && salary < 12999.99) {
			ES = 150.00; //5
		}
		else if(salary >= 13000.00 && salary < 13999.99) {
			ES = 162.50; //6
		}
		else if(salary >= 14000.00 && salary < 14999.99) {
			ES = 175.00; //7
		}
		else if(salary >= 15000.00 && salary < 15999.99) {
			ES = 187.50; //8
		}
		else if(salary >= 16000.00 && salary < 16999.99) {
			ES = 200.00; //9
		}
		else if(salary >= 17000.00 && salary < 17999.99) {
			ES = 212.50; //10
		}
		else if(salary >= 18000.00 && salary < 18999.99) {
			ES = 225.00; //11
		}
		else if(salary >= 19000.00 && salary < 19999.99) {
			ES = 237.50; //12
		}
		else if(salary >= 20000.00 && salary < 20999.99) {
			ES = 250.00; //13
		}
		else if(salary >= 21000.00 && salary < 21999.99) {
			ES = 262.50; //14
		}
		else if(salary >= 22000.00 && salary < 22999.99) {
			ES = 275.00; //15
		}
		else if(salary >= 23000.00 && salary < 23999.99) {
			ES = 287.50; //16
		}
		else if(salary >= 24000.00 && salary < 24999.99) {
			ES = 300.00; //17
		}
		else if(salary >= 25000.00 && salary < 25999.99) {
			ES = 312.50; //18
		}
		else if(salary >= 26000.00 && salary < 26999.99) {
			ES = 325.00; //19
		}
		else if(salary >= 27000.00 && salary < 27999.99) {
			ES = 337.50; //20
		}
		else if(salary >= 28000.00 && salary < 28999.99) {
			ES = 350.00; //21
		}
		else if(salary >= 29000.00 && salary < 29999.99) {
			ES = 362.50; //22
		}
		else if(salary >= 30000.00 && salary < 30999.99) {
			ES = 375.00; //23
		}
		else if(salary >= 31000.00 && salary < 31999.99) {
			ES = 387.50; //24
		}
		else if(salary >= 32000.00 && salary < 32999.99) {
			ES = 400.00; //25
		}
		else if(salary >= 33000.00 && salary < 33999.99) {
			ES = 412.50; //26
		}
		else if(salary >= 34000.00 && salary < 34999.99) {
			ES = 425.00; //27
		}
		else if(salary > 35000) {
			ES = 437.50; //28
		}
		
		return ES;
	}
	
	public static void main(String[] args) {
		String firstName, lastName, company;
		double money = 0,tax, share, PH_ES;
		int  SSS_EE;
		char choice = 'y';
		
		Scanner inputString = new Scanner(System.in);
		Scanner myChoice = new Scanner(System.in);
		
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2);
		
		do {
			System.out.print("Please enter your first name: "); //Name
			firstName = inputString.next();
			System.out.print("Please enter your last name: ");
			lastName = inputString.next();
			System.out.print("Please enter the name of your company: ");
			company = inputString.next();
			money = monthlySalary(money);//Monthly Salary
			System.out.print("\033[H\033[2J");
			System.out.flush();
			
			System.out.print("NAME OF EMPLOYEE: ");
			System.out.println(firstName+" "+lastName);
			System.out.print("NAME OF COMPANY: ");
			System.out.println(company);
			System.out.print("MONTHLY SALARY: ");
			System.out.println(df.format(money));
			System.out.println();
			
			tax = incomeTax(money);//Income Tax
			System.out.print("INCOME TAX: ");
			System.out.println(df.format(tax));
			SSS_EE = SSS(money);//SSS
			System.out.println("SSS: "+SSS_EE);
			share = pagIbig(money); //Pag_Ibig
			System.out.print("PAG-IBIG: ");
			System.out.println(df.format(share));
			PH_ES = philHealth(money); //Phil_Health
			System.out.print("PHILHEALTH: ");
			System.out.println(df.format(PH_ES));
			
			System.out.println();
			System.out.print("ANOTHER INQUIRY [Y/N]? ");
			choice = myChoice.next().charAt(0);
			System.out.print("\033[H\033[2J");
			System.out.flush();
		} while(choice != 'n' && choice != 'N');
		
		System.out.print("\033[H\033[2J");
		System.out.flush();
		
		System.out.print("Exit!");
		
		inputString.close();
		myChoice.close();
	}

}
